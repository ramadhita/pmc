#include <stdio.h>
#include <math.h>

/* 
-> Perhitungan posisi kartesian terhadap tiap iterasi 10ms
-> Program bisa menampilkan : 
    -> Posisi (x,y) setiap 10ms
    -> Jarak terjauh yang ditempuh objek
*/
#define PI 3.141592654
#define gravitasi 10
#define speed 50
#define sudut 60

int main(void)
{
    double rad;
    double speedx, speedy, jarakx, jaraky;

    // Variabel Konstan
    rad = sudut*PI/180; // radian

    // Variabel kondisi awal
    jarakx = 0;
    jaraky = 0;

    //Komponen kecepatan sumbu x dan y
    speedx = cos(rad)*speed;
    speedy = sin(rad)*speed;

    for (double time = 0; jaraky >= 0; time += 0.01)
    {
        /* code */
        jaraky = (speedy * time) - (time * time * gravitasi / 2);
        jarakx = speedx * time;
        printf("Waktu : %4.2lf s,  Jarak X : %6.2lf m, Jarak Y : %6.4lf m \n", time, jarakx, jaraky);
    }
    printf("Jarak Maksimal yang dicapai: %6.2f m", jarakx);
    return (0);
}
    
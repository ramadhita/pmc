#include <stdio.h>

int main()
{
    double hasil1, hasil2, hasil3, hasil4;
    int i;

    hasil1=0;
    for (i = 0; i <= 1000000; i++)
    {
        hasil1 += (0 + 0.000007*i)*0.000007;
    }

    hasil2 = 0;
    for (i = 0; i < 1000000; i++)
    {
        hasil2 += 0.000006283185307;
    }

    hasil3 = hasil1 * hasil2;
    hasil4 = hasil3 - (3.14159265359 * 7 * 7);



    printf("Luas lingkaran menurut program : %lf\n", hasil3);
    printf("galat program : %lf\n", hasil4);
    return 0;
}

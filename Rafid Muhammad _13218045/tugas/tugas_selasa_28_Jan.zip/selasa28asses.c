#include <stdio.h>

struct tipe
{
    char nama[20];
    char indeks;
    int nilai;
};

int largest(struct tipe arr[])
{
    int i;
    int max = arr[0].nilai;
    int index = 0;

    for (i = 1; i < 5; i++)
    {
        if(arr[i].nilai > max)
        {
            max = arr[i].nilai,
            index = i;
        }
    }
return max;
}

int largidx(struct tipe arr[])
{
    int i;
    int max = arr[0].nilai;
    int index = 0;

    for (i = 1; i < 5; i++)
    {
        if(arr[i].nilai > max)
        {
            max = arr[i].nilai,
            index = i;
        }
    }
return index;
}

int smallest(struct tipe arr[])
{
    int i;
    int min = arr[0].nilai;
    int index = 0;

    for (i = 1; i < 5; i++)
    {
        if(arr[i].nilai < min)
        {
            min = arr[i].nilai,
            index = i;
        }
    }
return min;
}

int smallidx(struct tipe arr[])
{
    int i;
    int min = arr[0].nilai;
    int index = 0;

    for (i = 1; i < 5; i++)
    {
        if(arr[i].nilai < min)
        {
            min = arr[i].nilai,
            index = i;
        }
    }
return index;
}

float rataan(struct tipe arr[])
{
    int i;
    int jumlah = 0;
    float rerata;
    for(i = 0; i < 5; i++)
    {
        jumlah += arr[i].nilai;
    }
    rerata = jumlah / 5;

    return rerata;
}









int main()
{

int i;
struct tipe data[5];

data[0].nilai = 67;
strcpy(data[0].nama, "Mawar");

data[1].nilai = 85;
strcpy(data[1].nama, "Melati");

data[2].nilai = 85;
strcpy(data[2].nama, "Wisteria");

data[3].nilai = 70;
strcpy(data[3].nama, "Carnation");

data[4].nilai = 60;
strcpy(data[4].nama,"Lili");


/* printf("%d", data[0].nilai);
printf("%s", data[0].nama); */


for(i = 0; i < 5; i++){
    if (data[i].nilai >= 85 )
    {
        data[i].indeks = 'A';
    }
    else if ((data[i].nilai >= 70) && (data[i].nilai < 85))
    {
        data[i].indeks = 'B';
    }
    else if ((data[i].nilai >= 67) && (data[i].nilai < 70))
    {
        data[i].indeks = 'C';
    }
    else
    {
        data[i].indeks = 'D';
    }
}


printf("Nilai terbesar : %s ", data[largidx(data)].nama);
printf("%d ",largest(data));
printf("%c\n", data[largidx(data)].indeks);

printf("Nilai terkecil : %s ", data[smallidx(data)].nama);
printf("%d ",smallest(data));
printf("%c\n", data[smallidx(data)].indeks);

printf("Rata-rata nilai : %f", rataan(data));
return 0;
}
